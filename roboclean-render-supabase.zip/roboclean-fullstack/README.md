# RoboClean Full-Stack Website

RoboClean is a responsive robotic-vacuum project showcase with an Express backend, Supabase PostgreSQL storage, login/registration, an admin dashboard, contact messages, project settings, and a secured robot telemetry endpoint.

## Included

- Static frontend: `public/index.html`, `public/login.html`, `public/dashboard.html`
- Node.js/Express API: `server.js`
- Supabase PostgreSQL tables: `users`, `messages`, `settings`, `telemetry`
- PostgreSQL-backed login sessions (`user_sessions`)
- Password hashing, session cookies, CSRF checks, rate limiting, parameterized SQL
- `render.yaml` blueprint for a free Render web service

## Deploy on Render + Supabase

1. Push this folder to a GitHub repository. Do not upload `.env` or any secrets.
2. In Render, choose **New → Blueprint** and connect the repository containing `render.yaml`.
3. Render reads `render.yaml`. In the service's Environment settings, set `DATABASE_URL` to your Supabase **PostgreSQL Transaction Pooler** connection string (backend only). Keep `NODE_ENV=production`; Render generates `SESSION_SECRET` and `ROBOT_API_KEY` automatically.
4. Deploy. When it finishes, open `https://YOUR-SERVICE.onrender.com/api/health`; a healthy response looks like `{"ok":true,"service":"RoboClean API"}`.
5. Create the first admin account using the one-time script below, from a computer or Termux environment with Node.js and network access to Supabase. Do not use a public/default password.

### Database

The connected Supabase project must have `public.users`, `public.messages`, `public.settings`, and `public.telemetry`. The server seeds default settings and creates `public.user_sessions` on startup. Use a backend PostgreSQL connection string; never put it in frontend JavaScript, and never use a Supabase secret/service-role key in the browser.

For the `DATABASE_URL`, open Supabase Dashboard → **Connect** → **Transaction pooler** and copy the PostgreSQL URI. If the password has special characters, use the exact URI supplied by Supabase or percent-encode them correctly. Add it only to Render's private Environment settings; don't paste it into chat, GitHub, or screenshots.

## Create the first admin account

From the project folder on a trusted computer or Termux, create a local `.env` (copy `.env.example`) and set:

- `DATABASE_URL`: Supabase Transaction Pooler URI
- `ADMIN_EMAIL`: the email for your admin login
- `ADMIN_PASSWORD`: a unique password with at least 12 characters

Then run:

```bash
npm install
npm run create-admin
```

The script creates or promotes the supplied email to admin and updates its password. Keep `.env` private; `.gitignore` excludes it. After successful creation, remove `ADMIN_PASSWORD` from the local `.env` if you no longer need it. You can then sign in at `/login.html` on the deployed site.

## Local development

```bash
npm install
cp .env.example .env
# Edit .env with DATABASE_URL, SESSION_SECRET, ROBOT_API_KEY
npm start
```

Open `http://localhost:3000`. Use a strong, unique `SESSION_SECRET` (at least 32 characters) and `ROBOT_API_KEY` (at least 24 characters).

## API overview

- `GET /api/health` — service health check
- `GET /api/project` — public project settings
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout` — account/session endpoints
- `POST /api/messages` — public contact form (CSRF protected)
- `/api/admin/*` — authenticated admin endpoints
- `POST /api/robot/telemetry` — accepts JSON authenticated with `X-Robot-Key` or `Authorization: Bearer ...`

Telemetry body example:

```json
{
  "battery_percent": 78,
  "obstacle_detected": false,
  "cleaning_state": "cleaning",
  "distance_cm": 23.5
}
```

The telemetry endpoint only stores values sent by a compatible Arduino/ESP32 client; it does not control hardware by itself.

## Free-tier notes

Render's free web service may sleep after inactivity and the first request after sleeping may be slow. Supabase free-tier limits and pause policies can change; check the current dashboards for account-specific limits. The service depends on the Supabase database remaining available.
