require('dotenv').config();
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

(async () => {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (!process.env.DATABASE_URL) {
    console.error('Set DATABASE_URL to your Supabase PostgreSQL connection string.');
    process.exit(1);
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD (at least 12 characters) in .env, then run npm run create-admin.');
    process.exit(1);
  }
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined,
    max: 2,
    connectionTimeoutMillis: 10000
  });
  try {
    const hash = await bcrypt.hash(password, 12);
    const name = email.split('@')[0].slice(0, 80) || 'RoboClean Admin';
    await pool.query(`INSERT INTO public.users(name,email,password_hash,role)
      VALUES ($1,$2,$3,'admin')
      ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash, role='admin'`, [name, email, hash]);
    console.log(`Admin account ready for ${email}. Remove ADMIN_PASSWORD from your environment after setup.`);
  } finally {
    await pool.end();
  }
})().catch(error => { console.error('Could not create admin account:', error.message); process.exit(1); });
