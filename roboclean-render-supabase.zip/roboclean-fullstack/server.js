require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

if (!process.env.DATABASE_URL) {
  console.error('Set DATABASE_URL to your Supabase PostgreSQL connection string.');
  process.exit(1);
}
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('Set SESSION_SECRET to a random value at least 32 characters long.');
  process.exit(1);
}
if (!process.env.ROBOT_API_KEY || process.env.ROBOT_API_KEY.length < 24) {
  console.error('Set ROBOT_API_KEY to a separate random value at least 24 characters long.');
  process.exit(1);
}

// Use the Supabase Transaction Pooler connection string for hosted deployments.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isProduction ? { rejectUnauthorized: false } : undefined,
  max: 5,
  idleTimeoutMillis: 10000,
  connectionTimeoutMillis: 10000
});
pool.on('error', err => console.error('Unexpected PostgreSQL pool error:', err.message));

const defaultSettings = {
  project_name: 'RoboClean',
  project_description: 'An Arduino-based robotic vacuum cleaner college project.',
  team_name: 'RoboClean Project Team',
  robot_status: 'Prototype / demo mode'
};

async function initializeDatabase() {
  // The four public tables are created in the connected Supabase project already.
  // This statement safely seeds default settings without replacing admin edits.
  for (const [key, value] of Object.entries(defaultSettings)) {
    await pool.query('INSERT INTO public.settings(key, value) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING', [key, value]);
  }
  await pool.query(`CREATE TABLE IF NOT EXISTS public.user_sessions (
    sid varchar NOT NULL PRIMARY KEY,
    sess json NOT NULL,
    expire timestamptz NOT NULL
  )`);
}

app.disable('x-powered-by');
if (isProduction) app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: false, pruneSessionInterval: 15 * 60 }),
  name: 'roboclean.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false });
const messageLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false });

function cleanText(value, max) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function safeUser(user) {
  return user ? { id: user.id, name: user.name, email: user.email, role: user.role, created_at: user.created_at } : null;
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please sign in first.' });
  pool.query('SELECT id,name,email,role,created_at FROM public.users WHERE id=$1', [req.session.userId])
    .then(({ rows }) => {
      const user = rows[0];
      if (!user) {
        req.session.destroy(() => {});
        return res.status(401).json({ error: 'Session expired. Please sign in again.' });
      }
      req.user = user;
      next();
    }).catch(error => safeError(res, error));
}
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  next();
}
function requireCsrf(req, res, next) {
  const token = req.get('X-CSRF-Token');
  if (!req.session.csrfToken || !token || token !== req.session.csrfToken) {
    return res.status(403).json({ error: 'Security token expired. Refresh and try again.' });
  }
  next();
}
function makeCsrf(req) {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  return req.session.csrfToken;
}
function safeError(res, error) {
  console.error(error);
  if (!res.headersSent) res.status(500).json({ error: 'Something went wrong. Please try again.' });
}
function isDuplicateEmail(error) {
  return error && error.code === '23505' && (error.constraint || '').includes('email');
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'RoboClean API' }));
app.get('/api/csrf', (req, res) => res.json({ token: makeCsrf(req) }));
app.get('/api/auth/me', async (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  try {
    const { rows } = await pool.query('SELECT id,name,email,role,created_at FROM public.users WHERE id=$1', [req.session.userId]);
    res.json({ user: safeUser(rows[0]) });
  } catch (error) { safeError(res, error); }
});
app.post('/api/auth/register', authLimiter, requireCsrf, async (req, res) => {
  const name = cleanText(req.body.name, 80);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10 || password.length > 128) {
    return res.status(400).json({ error: 'Enter a name, valid email, and password of 10–128 characters.' });
  }
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const { rows } = await pool.query(
      "INSERT INTO public.users(name,email,password_hash,role) VALUES ($1,$2,$3,'user') RETURNING id,name,email,role,created_at",
      [name, email, passwordHash]
    );
    req.session.regenerate(err => {
      if (err) return safeError(res, err);
      req.session.userId = rows[0].id;
      makeCsrf(req);
      req.session.save(saveErr => {
        if (saveErr) return safeError(res, saveErr);
        res.status(201).json({ user: safeUser(rows[0]) });
      });
    });
  } catch (error) {
    if (isDuplicateEmail(error)) return res.status(409).json({ error: 'An account with that email already exists.' });
    safeError(res, error);
  }
});
app.post('/api/auth/login', authLimiter, requireCsrf, async (req, res) => {
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  try {
    const { rows } = await pool.query('SELECT * FROM public.users WHERE email=$1', [email]);
    const user = rows[0];
    const ok = user && await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Email or password is incorrect.' });
    req.session.regenerate(err => {
      if (err) return safeError(res, err);
      req.session.userId = user.id;
      makeCsrf(req);
      req.session.save(saveErr => {
        if (saveErr) return safeError(res, saveErr);
        res.json({ user: safeUser(user) });
      });
    });
  } catch (error) { safeError(res, error); }
});
app.post('/api/auth/logout', requireAuth, requireCsrf, (req, res) => {
  req.session.destroy(err => {
    if (err) return safeError(res, err);
    res.clearCookie('roboclean.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction });
    res.json({ ok: true });
  });
});

app.post('/api/messages', messageLimiter, requireCsrf, async (req, res) => {
  const name = cleanText(req.body.name, 80);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const message = cleanText(req.body.message, 3000);
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 5) {
    return res.status(400).json({ error: 'Please provide a name, valid email, and a message of at least 5 characters.' });
  }
  try {
    await pool.query('INSERT INTO public.messages(name,email,message) VALUES ($1,$2,$3)', [name, email, message]);
    res.status(201).json({ ok: true });
  } catch (error) { safeError(res, error); }
});

app.get('/api/project', async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT key,value FROM public.settings');
    res.json(Object.fromEntries(rows.map(row => [row.key, row.value])));
  } catch (error) { safeError(res, error); }
});
app.get('/api/admin/summary', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const [users, messages, telemetry, latest] = await Promise.all([
      pool.query('SELECT COUNT(*)::int AS count FROM public.users'),
      pool.query("SELECT COUNT(*)::int AS count FROM public.messages WHERE status='new'"),
      pool.query('SELECT COUNT(*)::int AS count FROM public.telemetry'),
      pool.query('SELECT battery_percent,obstacle_detected,cleaning_state,distance_cm,created_at FROM public.telemetry ORDER BY id DESC LIMIT 1')
    ]);
    res.json({ users: users.rows[0].count, messages: messages.rows[0].count, telemetry: telemetry.rows[0].count, latest: latest.rows[0] || null });
  } catch (error) { safeError(res, error); }
});
app.get('/api/admin/messages', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT id,name,email,message,status,created_at FROM public.messages ORDER BY id DESC LIMIT 200');
    res.json({ messages: rows });
  } catch (error) { safeError(res, error); }
});
app.patch('/api/admin/messages/:id', requireAuth, requireAdmin, requireCsrf, async (req, res) => {
  const status = cleanText(req.body.status, 20);
  if (!['new','read','archived'].includes(status)) return res.status(400).json({ error: 'Invalid message status.' });
  try {
    const { rowCount } = await pool.query('UPDATE public.messages SET status=$1 WHERE id=$2', [status, Number(req.params.id)]);
    if (!rowCount) return res.status(404).json({ error: 'Message not found.' });
    res.json({ ok: true });
  } catch (error) { safeError(res, error); }
});
app.delete('/api/admin/messages/:id', requireAuth, requireAdmin, requireCsrf, async (req, res) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM public.messages WHERE id=$1', [Number(req.params.id)]);
    if (!rowCount) return res.status(404).json({ error: 'Message not found.' });
    res.json({ ok: true });
  } catch (error) { safeError(res, error); }
});
app.get('/api/admin/users', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT id,name,email,role,created_at FROM public.users ORDER BY id DESC LIMIT 200');
    res.json({ users: rows });
  } catch (error) { safeError(res, error); }
});
app.get('/api/admin/settings', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT key,value FROM public.settings');
    res.json(Object.fromEntries(rows.map(row => [row.key, row.value])));
  } catch (error) { safeError(res, error); }
});
app.put('/api/admin/settings', requireAuth, requireAdmin, requireCsrf, async (req, res) => {
  const allowed = ['project_name','project_description','team_name','robot_status'];
  const client = await pool.connect().catch(error => { safeError(res, error); return null; });
  if (!client) return;
  try {
    await client.query('BEGIN');
    for (const key of allowed) {
      if (typeof req.body[key] === 'string') {
        await client.query('INSERT INTO public.settings(key,value) VALUES ($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value',
          [key, cleanText(req.body[key], key === 'project_description' ? 1000 : 160)]);
      }
    }
    await client.query('COMMIT');
    res.json({ ok: true });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    safeError(res, error);
  } finally { client.release(); }
});
app.get('/api/admin/telemetry', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT id,battery_percent,obstacle_detected,cleaning_state,distance_cm,created_at FROM public.telemetry ORDER BY id DESC LIMIT 50');
    res.json({ telemetry: rows });
  } catch (error) { safeError(res, error); }
});

// Arduino/ESP32 can POST JSON here using the ROBOT_API_KEY as a bearer token.
app.post('/api/robot/telemetry', async (req, res) => {
  const key = req.get('X-Robot-Key') || (req.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  const expected = process.env.ROBOT_API_KEY;
  const keyBuffer = Buffer.from(String(key || ''));
  const expectedBuffer = Buffer.from(expected);
  if (keyBuffer.length !== expectedBuffer.length || !crypto.timingSafeEqual(keyBuffer, expectedBuffer)) {
    return res.status(401).json({ error: 'Invalid robot API key.' });
  }
  const battery = req.body.battery_percent;
  const obstacle = req.body.obstacle_detected;
  const state = cleanText(req.body.cleaning_state || 'idle', 40);
  const distance = req.body.distance_cm;
  if (battery != null && (!Number.isInteger(battery) || battery < 0 || battery > 100)) return res.status(400).json({ error: 'battery_percent must be an integer from 0 to 100.' });
  if (distance != null && (typeof distance !== 'number' || !Number.isFinite(distance) || distance < 0 || distance > 10000)) return res.status(400).json({ error: 'distance_cm must be a valid non-negative number.' });
  if (typeof obstacle !== 'boolean' && obstacle != null) return res.status(400).json({ error: 'obstacle_detected must be true or false.' });
  if (!['idle','cleaning','paused','charging','error'].includes(state)) return res.status(400).json({ error: 'Invalid cleaning_state.' });
  try {
    await pool.query('INSERT INTO public.telemetry(battery_percent,obstacle_detected,cleaning_state,distance_cm,raw_json) VALUES ($1,$2,$3,$4,$5)',
      [battery == null ? null : battery, obstacle ? 1 : 0, state, distance == null ? null : distance, JSON.stringify(req.body).slice(0, 4000)]);
    res.status(201).json({ ok: true });
  } catch (error) { safeError(res, error); }
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found.' });
  next();
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(400).json({ error: 'Invalid request.' });
});

initializeDatabase().then(() => {
  app.listen(PORT, () => console.log(`RoboClean running on port ${PORT}`));
}).catch(error => {
  console.error('Could not initialize RoboClean database:', error.message);
  process.exit(1);
});
