require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('Set SESSION_SECRET in .env to a random value at least 32 characters long.');
  process.exit(1);
}
if (!process.env.ROBOT_API_KEY || process.env.ROBOT_API_KEY.length < 24) {
  console.error('Set ROBOT_API_KEY in .env to a separate random value at least 24 characters long.');
  process.exit(1);
}

const db = new Database(path.join(dataDir, 'roboclean.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new','read','archived')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    battery_percent INTEGER,
    obstacle_detected INTEGER NOT NULL DEFAULT 0,
    cleaning_state TEXT NOT NULL DEFAULT 'idle',
    distance_cm REAL,
    raw_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
const defaultSettings = {
  project_name: 'RoboClean',
  project_description: 'An Arduino-based robotic vacuum cleaner college project.',
  team_name: 'RoboClean Project Team',
  robot_status: 'Prototype / demo mode'
};
const insertSetting = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)');
for (const [key, value] of Object.entries(defaultSettings)) insertSetting.run(key, value);

app.disable('x-powered-by');
if (isProduction) app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

const SQLiteStore = SQLiteStoreFactory(session);
app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: dataDir, concurrentDB: true }),
  name: 'roboclean.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false });
const messageLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false });

function cleanText(value, max) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function safeUser(user) {
  return user ? { id: user.id, name: user.name, email: user.email, role: user.role, created_at: user.created_at } : null;
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please sign in first.' });
  const user = db.prepare('SELECT id,name,email,role,created_at FROM users WHERE id=?').get(req.session.userId);
  if (!user) { req.session.destroy(() => {}); return res.status(401).json({ error: 'Session expired. Please sign in again.' }); }
  req.user = user;
  next();
}
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  next();
}
function requireCsrf(req, res, next) {
  const token = req.get('X-CSRF-Token');
  if (!req.session.csrfToken || !token || token !== req.session.csrfToken) {
    return res.status(403).json({ error: 'Security token expired. Refresh and try again.' });
  }
  next();
}
function makeCsrf(req) {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  return req.session.csrfToken;
}
function safeError(res, error) {
  console.error(error);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'RoboClean API' }));
app.get('/api/csrf', (req, res) => res.json({ token: makeCsrf(req) }));
app.get('/api/auth/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = db.prepare('SELECT id,name,email,role,created_at FROM users WHERE id=?').get(req.session.userId);
  res.json({ user: safeUser(user) });
});
app.post('/api/auth/register', authLimiter, requireCsrf, async (req, res) => {
  const name = cleanText(req.body.name, 80);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10 || password.length > 128) {
    return res.status(400).json({ error: 'Enter a name, valid email, and password of 10–128 characters.' });
  }
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES (?,?,?,?)')
      .run(name, email, passwordHash, 'user');
    req.session.regenerate(err => {
      if (err) return safeError(res, err);
      req.session.userId = Number(result.lastInsertRowid);
      makeCsrf(req);
      res.status(201).json({ user: safeUser(db.prepare('SELECT id,name,email,role,created_at FROM users WHERE id=?').get(req.session.userId)) });
    });
  } catch (error) {
    if (String(error.code || '').includes('SQLITE_CONSTRAINT')) return res.status(409).json({ error: 'An account with that email already exists.' });
    safeError(res, error);
  }
});
app.post('/api/auth/login', authLimiter, requireCsrf, async (req, res) => {
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  const ok = user && await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Email or password is incorrect.' });
  req.session.regenerate(err => {
    if (err) return safeError(res, err);
    req.session.userId = user.id;
    makeCsrf(req);
    res.json({ user: safeUser(user) });
  });
});
app.post('/api/auth/logout', requireAuth, requireCsrf, (req, res) => {
  req.session.destroy(err => {
    if (err) return safeError(res, err);
    res.clearCookie('roboclean.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction });
    res.json({ ok: true });
  });
});

app.post('/api/messages', messageLimiter, requireCsrf, (req, res) => {
  const name = cleanText(req.body.name, 80);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const message = cleanText(req.body.message, 3000);
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 5) {
    return res.status(400).json({ error: 'Please provide a name, valid email, and a message of at least 5 characters.' });
  }
  try {
    db.prepare('INSERT INTO messages(name,email,message) VALUES (?,?,?)').run(name, email, message);
    res.status(201).json({ ok: true });
  } catch (error) { safeError(res, error); }
});

app.get('/api/project', (_req, res) => {
  const rows = db.prepare('SELECT key,value FROM settings').all();
  res.json(Object.fromEntries(rows.map(row => [row.key, row.value])));
});
app.get('/api/admin/summary', requireAuth, requireAdmin, (_req, res) => {
  res.json({
    users: db.prepare('SELECT COUNT(*) AS count FROM users').get().count,
    messages: db.prepare("SELECT COUNT(*) AS count FROM messages WHERE status='new'").get().count,
    telemetry: db.prepare('SELECT COUNT(*) AS count FROM telemetry').get().count,
    latest: db.prepare('SELECT battery_percent,obstacle_detected,cleaning_state,distance_cm,created_at FROM telemetry ORDER BY id DESC LIMIT 1').get() || null
  });
});
app.get('/api/admin/messages', requireAuth, requireAdmin, (_req, res) => {
  res.json({ messages: db.prepare('SELECT id,name,email,message,status,created_at FROM messages ORDER BY id DESC LIMIT 200').all() });
});
app.patch('/api/admin/messages/:id', requireAuth, requireAdmin, requireCsrf, (req, res) => {
  const status = cleanText(req.body.status, 20);
  if (!['new','read','archived'].includes(status)) return res.status(400).json({ error: 'Invalid message status.' });
  const result = db.prepare('UPDATE messages SET status=? WHERE id=?').run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: 'Message not found.' });
  res.json({ ok: true });
});
app.delete('/api/admin/messages/:id', requireAuth, requireAdmin, requireCsrf, (req, res) => {
  const result = db.prepare('DELETE FROM messages WHERE id=?').run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: 'Message not found.' });
  res.json({ ok: true });
});
app.get('/api/admin/users', requireAuth, requireAdmin, (_req, res) => {
  res.json({ users: db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC LIMIT 200').all() });
});
app.get('/api/admin/settings', requireAuth, requireAdmin, (_req, res) => {
  res.json(Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(row => [row.key,row.value])));
});
app.put('/api/admin/settings', requireAuth, requireAdmin, requireCsrf, (req, res) => {
  const allowed = ['project_name','project_description','team_name','robot_status'];
  const update = db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  const tx = db.transaction(() => {
    for (const key of allowed) {
      if (typeof req.body[key] === 'string') update.run(key, cleanText(req.body[key], key === 'project_description' ? 1000 : 160));
    }
  });
  tx();
  res.json({ ok: true });
});
app.get('/api/admin/telemetry', requireAuth, requireAdmin, (_req, res) => {
  res.json({ telemetry: db.prepare('SELECT id,battery_percent,obstacle_detected,cleaning_state,distance_cm,created_at FROM telemetry ORDER BY id DESC LIMIT 50').all() });
});

// Arduino/ESP32 can POST JSON here using the ROBOT_API_KEY as a bearer token.
// Example body: {"battery_percent":78,"obstacle_detected":false,"cleaning_state":"cleaning","distance_cm":23.5}
app.post('/api/robot/telemetry', (req, res) => {
  const key = req.get('X-Robot-Key') || (req.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  const expected = process.env.ROBOT_API_KEY;
  const keyBuffer = Buffer.from(String(key || ''));
  const expectedBuffer = Buffer.from(expected);
  if (keyBuffer.length !== expectedBuffer.length || !crypto.timingSafeEqual(keyBuffer, expectedBuffer)) {
    return res.status(401).json({ error: 'Invalid robot API key.' });
  }
  const battery = req.body.battery_percent;
  const obstacle = req.body.obstacle_detected;
  const state = cleanText(req.body.cleaning_state || 'idle', 40);
  const distance = req.body.distance_cm;
  if (battery != null && (!Number.isInteger(battery) || battery < 0 || battery > 100)) return res.status(400).json({ error: 'battery_percent must be an integer from 0 to 100.' });
  if (distance != null && (typeof distance !== 'number' || !Number.isFinite(distance) || distance < 0 || distance > 10000)) return res.status(400).json({ error: 'distance_cm must be a valid non-negative number.' });
  if (typeof obstacle !== 'boolean' && obstacle != null) return res.status(400).json({ error: 'obstacle_detected must be true or false.' });
  if (!['idle','cleaning','paused','charging','error'].includes(state)) return res.status(400).json({ error: 'Invalid cleaning_state.' });
  try {
    db.prepare('INSERT INTO telemetry(battery_percent,obstacle_detected,cleaning_state,distance_cm,raw_json) VALUES (?,?,?,?,?)')
      .run(battery == null ? null : battery, obstacle ? 1 : 0, state, distance == null ? null : distance, JSON.stringify(req.body).slice(0, 4000));
    res.status(201).json({ ok: true });
  } catch (error) { safeError(res, error); }
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found.' });
  next();
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(400).json({ error: 'Invalid request.' });
});

app.listen(PORT, () => console.log(`RoboClean running at http://localhost:${PORT}`));
