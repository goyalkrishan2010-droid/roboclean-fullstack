require('dotenv').config();
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

(async () => {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD (at least 12 characters) in .env, then run npm run create-admin.');
    process.exit(1);
  }
  const dataDir = path.join(__dirname, 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  const db = new Database(path.join(dataDir, 'roboclean.db'));
  db.exec(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
  const hash = await bcrypt.hash(password, 12);
  const name = email.split('@')[0].slice(0, 80) || 'RoboClean Admin';
  db.prepare(`INSERT INTO users(name,email,password_hash,role) VALUES (?,?,?,'admin')
    ON CONFLICT(email) DO UPDATE SET password_hash=excluded.password_hash, role='admin'`).run(name, email, hash);
  console.log(`Admin account ready for ${email}. Remove ADMIN_PASSWORD from .env after setup if you prefer.`);
  db.close();
})().catch(error => { console.error(error); process.exit(1); });
