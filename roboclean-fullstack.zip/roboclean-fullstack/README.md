# RoboClean Full-Stack Website

A starter full-stack website for an Arduino robotic vacuum cleaner college project. It includes the existing responsive public showcase, Express backend, SQLite database, secure password hashing, session-based login, an admin dashboard, contact message storage, project settings, and an authenticated-by-key robot telemetry endpoint.

## Stack

- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Node.js + Express
- Database: SQLite (`data/roboclean.db`)
- Authentication: server-side sessions, `bcryptjs` password hashing
- Security basics: Helmet, rate limits on authentication/contact forms, HttpOnly SameSite session cookie, CSRF token checks on state-changing browser routes, role checks, parameterized SQL queries

## Requirements

Install Node.js 20 or newer from https://nodejs.org/ . `better-sqlite3` may require build tools on some operating systems. Use a laptop/desktop for the easiest setup; running a Node server on an Android phone is possible with tools such as Termux but is less beginner-friendly.

## Run locally

1. Extract the ZIP.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`.
5. Replace `SESSION_SECRET` and `ROBOT_API_KEY` with long, unique random values. Set your admin email and a strong admin password of at least 12 characters.
6. Create the admin account:

   ```bash
   npm run create-admin
   ```

7. Start the server:

   ```bash
   npm start
   ```

8. Open `http://localhost:3000`. Sign in at `http://localhost:3000/login.html`; the seeded admin account has dashboard access. Public visitors can also create standard user accounts.

**Important:** There is no default admin password. You must configure your own in `.env`. Never publish `.env`, share your admin password, or commit secrets to Git.

## Dashboard

- Overview: account count, new contact messages, telemetry count, last reported robot state
- Messages: review, mark read/new, or delete contact form submissions
- Users: list registered accounts and roles
- Project settings: edit the team name, project description, and prototype status
- Robot telemetry: inspect sensor readings sent by a compatible controller

## Arduino / ESP32 telemetry endpoint

`POST /api/robot/telemetry` expects JSON and a private key in `X-Robot-Key` (or `Authorization: Bearer ...`). Example request body:

```json
{
  "battery_percent": 78,
  "obstacle_detected": true,
  "cleaning_state": "cleaning",
  "distance_cm": 23.5
}
```

Example test with curl (replace the key with the value in your local `.env`):

```bash
curl -X POST http://localhost:3000/api/robot/telemetry \
  -H "Content-Type: application/json" \
  -H "X-Robot-Key: YOUR_ROBOT_API_KEY" \
  -d '{"battery_percent":78,"obstacle_detected":true,"cleaning_state":"cleaning","distance_cm":23.5}'
```

The Arduino itself generally cannot call a website API over Wi-Fi unless the board/controller has network capability (for example, ESP32 or an Arduino plus Wi-Fi module) and suitable firmware. A basic USB-only Arduino needs a gateway computer or an added network module. This endpoint records incoming readings; it does **not** drive the motors or implement robot safety.

## Before public deployment

This is a college-project starter, not a security-audited production system. Before exposing it to the internet:
- Use HTTPS and set `NODE_ENV=production`.
- Use a strong, unique `SESSION_SECRET` and `ROBOT_API_KEY`.
- Back up the SQLite database and consider a managed database for multi-instance hosting.
- Add email verification, password reset, privacy notice, and stronger operational monitoring if needed.
- Keep the admin route and robot API key private. Rotate the robot key if it leaks.
- Test permissions and backups. Do not expose a local development server directly to the public internet.
- `public/index.html` is the public showcase. Dashboard project settings are stored in SQLite; connecting them to every public text element is a separate UI enhancement.
- Never rely on the website for physical robot collision avoidance, cliff detection, or emergency stopping. Implement and test these in the robot's hardware/firmware.

## Project structure

```text
roboclean-fullstack/
├── public/
│   ├── index.html
│   ├── login.html
│   └── dashboard.html
├── data/                 # SQLite database is created here
├── server.js
├── create-admin.js
├── package.json
├── .env.example
└── README.md
```
